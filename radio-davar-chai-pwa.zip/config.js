// Configure após contratar ou instalar o streaming.
// Exemplo: streamUrl: 'https://seu-servidor.exemplo/radio.mp3'
// A URL precisa ser pública, HTTPS e permitir reprodução no navegador.
// Para pedidos de oração, informe um e-mail real do ministério.
window.RADIO_CONFIG = {
  streamUrl: '',
  prayerEmail: ''
};
