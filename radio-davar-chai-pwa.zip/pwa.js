// PWA: instala a interface do site; o áudio ao vivo requer internet e servidor próprio.
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch(err => console.warn('PWA:', err));
  });
}
